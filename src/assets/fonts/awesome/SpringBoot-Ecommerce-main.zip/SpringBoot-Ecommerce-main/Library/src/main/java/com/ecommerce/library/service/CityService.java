package com.ecommerce.library.service;

import com.ecommerce.library.model.City;

import java.util.List;

public interface CityService {
    List<City> findAll();
}
